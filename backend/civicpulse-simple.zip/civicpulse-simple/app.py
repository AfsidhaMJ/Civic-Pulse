"""
app.py
CivicPulse — Flask backend
Saves every report form field to complaints.json and exposes
read / stats / status-update endpoints.

Fields captured from the Report a Problem form:
  full_name      — reporter's full name
  contact        — email or phone number
  category       — Roads | Lighting | Parks | Sanitation | Water | Safety
  category_emoji — emoji icon for the category
  title          — short problem title
  location       — street address or landmark
  description    — detailed description (optional)
  priority       — Low | Medium | High | Urgent
"""

import json
import os
import uuid
from datetime import datetime, timezone
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# ── Paths ─────────────────────────────────────────────────────────────────────

BASE_DIR       = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR   = os.path.join(BASE_DIR, "frontend")      # folder with dashboard.html
DATA_FILE      = os.path.join(BASE_DIR, "complaints.json")

# Ensure complaints.json exists with an empty list on first run
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump([], f)

# ── App setup ─────────────────────────────────────────────────────────────────

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)   # allow all origins (restrict in production via CORS_ORIGINS env var)

# ── Helpers ───────────────────────────────────────────────────────────────────

DEPT_MAP = {
    "Roads":      "Public Works",
    "Lighting":   "Utilities Board",
    "Parks":      "Parks & Recreation",
    "Sanitation": "Sanitation Dept.",
    "Water":      "Water Authority",
    "Safety":     "Emergency Services",
}

STATUS_PROGRESS = {
    "Submitted":  10,
    "Pending":    20,
    "In Review":  55,
    "Escalated":  70,
    "Resolved":  100,
}

VALID_CATEGORIES = list(DEPT_MAP.keys())
VALID_PRIORITIES = ["Low", "Medium", "High", "Urgent"]
VALID_STATUSES   = ["Submitted", "Pending", "In Review", "Escalated", "Resolved"]


def load_complaints() -> list:
    """Read and return all complaints from the JSON file."""
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_complaints(complaints: list) -> None:
    """Write the complaints list back to the JSON file."""
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(complaints, f, indent=2, ensure_ascii=False)


def next_ref(complaints: list) -> str:
    """Generate the next sequential reference number e.g. #1043."""
    if not complaints:
        return "#1000"
    try:
        last = max(int(c.get("ref_number", "#999").lstrip("#")) for c in complaints)
        return f"#{last + 1}"
    except (ValueError, AttributeError):
        return f"#{len(complaints) + 1000}"


def make_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Routes ────────────────────────────────────────────────────────────────────

# Health check
@app.get("/api/health")
def health():
    return jsonify({"success": True, "status": "ok", "timestamp": make_timestamp()})


# ── POST /api/report ──────────────────────────────────────────────────────────
@app.route("/api/report", methods=["POST"])
def report_issue():
    """
    Accept a new complaint from the Report a Problem form.
    Expects JSON body with all form fields.
    Saves a complete complaint record to complaints.json.
    """
    body = request.get_json(silent=True) or {}

    # ── Validation ────────────────────────────────────────────────────────────
    errors = []

    full_name = (body.get("full_name") or "").strip()
    if len(full_name) < 2:
        errors.append("full_name is required (min 2 characters).")

    contact = (body.get("contact") or "").strip()
    if len(contact) < 3:
        errors.append("contact (email or phone) is required.")

    category = (body.get("category") or "").strip()
    if category not in VALID_CATEGORIES:
        errors.append(f"category must be one of: {', '.join(VALID_CATEGORIES)}.")

    title = (body.get("title") or "").strip()
    if len(title) < 5:
        errors.append("title is required (min 5 characters).")

    location = (body.get("location") or "").strip()
    if len(location) < 3:
        errors.append("location is required.")

    priority = body.get("priority", "Medium")
    if priority not in VALID_PRIORITIES:
        errors.append(f"priority must be one of: {', '.join(VALID_PRIORITIES)}.")

    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    # ── Build complaint record ────────────────────────────────────────────────
    complaints = load_complaints()

    complaint = {
        # Identifiers
        "id":             str(uuid.uuid4())[:8],
        "ref_number":     next_ref(complaints),

        # ── All form fields ───────────────────────────────────────────────────
        "full_name":      full_name,
        "contact":        contact,
        "category":       category,
        "category_emoji": body.get("category_emoji") or "",
        "title":          title,
        "location":       location,
        "description":    (body.get("description") or "").strip() or None,
        "priority":       priority,

        # ── Auto-assigned fields ──────────────────────────────────────────────
        "authority":      DEPT_MAP.get(category, "Municipality"),
        "status":         "Submitted",
        "progress":       STATUS_PROGRESS["Submitted"],

        # ── Timeline ─────────────────────────────────────────────────────────
        "submitted_at":   make_timestamp(),
        "updated_at":     make_timestamp(),
        "timeline": [
            {
                "event":      "submitted",
                "label":      "Report Submitted",
                "description": f"Submitted by {full_name}",
                "timestamp":   make_timestamp(),
            },
            {
                "event":       "dispatched",
                "label":       f"Sent to {DEPT_MAP.get(category, 'Municipality')}",
                "description": "Automatically routed to the relevant authority",
                "timestamp":   make_timestamp(),
            },
        ],
    }

    complaints.append(complaint)
    save_complaints(complaints)

    return jsonify({
        "success": True,
        "message": "Complaint submitted successfully.",
        "data": complaint,
    }), 201


# ── GET /api/complaints ───────────────────────────────────────────────────────
@app.get("/api/complaints")
def get_complaints():
    """Return all complaints. Supports optional query filters."""
    complaints = load_complaints()

    status   = request.args.get("status")
    priority = request.args.get("priority")
    category = request.args.get("category")
    search   = request.args.get("search", "").lower()

    if status:
        complaints = [c for c in complaints if c.get("status") == status]
    if priority:
        complaints = [c for c in complaints if c.get("priority") == priority]
    if category:
        complaints = [c for c in complaints if c.get("category") == category]
    if search:
        complaints = [
            c for c in complaints
            if search in (c.get("title") or "").lower()
            or search in (c.get("location") or "").lower()
            or search in (c.get("full_name") or "").lower()
        ]

    return jsonify({
        "success": True,
        "total":   len(complaints),
        "data":    complaints,
    })


# ── GET /api/complaints/<id> ──────────────────────────────────────────────────
@app.get("/api/complaints/<complaint_id>")
def get_complaint(complaint_id):
    """Return a single complaint by its id."""
    complaints = load_complaints()
    complaint = next((c for c in complaints if c.get("id") == complaint_id), None)
    if not complaint:
        return jsonify({"success": False, "error": "Complaint not found."}), 404
    return jsonify({"success": True, "data": complaint})


# ── PATCH /api/complaints/<id>/status ────────────────────────────────────────
@app.route("/api/complaints/<complaint_id>/status", methods=["PATCH"])
def update_status(complaint_id):
    """Update the status of a complaint and append a timeline event."""
    body   = request.get_json(silent=True) or {}
    status = body.get("status", "")
    note   = (body.get("note") or "").strip() or None

    if status not in VALID_STATUSES:
        return jsonify({
            "success": False,
            "errors": [f"status must be one of: {', '.join(VALID_STATUSES)}."],
        }), 400

    complaints = load_complaints()
    complaint  = next((c for c in complaints if c.get("id") == complaint_id), None)

    if not complaint:
        return jsonify({"success": False, "error": "Complaint not found."}), 404

    now = make_timestamp()
    complaint["status"]     = status
    complaint["progress"]   = STATUS_PROGRESS.get(status, 20)
    complaint["updated_at"] = now
    complaint.setdefault("timeline", []).append({
        "event":       status.lower().replace(" ", "_"),
        "label":       status,
        "description": note,
        "timestamp":   now,
    })

    save_complaints(complaints)

    return jsonify({
        "success": True,
        "message": f"Status updated to '{status}'.",
        "data":    complaint,
    })


# ── GET /api/stats ────────────────────────────────────────────────────────────
@app.get("/api/stats")
def get_stats():
    """Summary statistics for the dashboard overview."""
    complaints = load_complaints()

    total    = len(complaints)
    by_status   = {}
    by_priority = {}
    by_category = {}

    for c in complaints:
        s = c.get("status", "Unknown")
        p = c.get("priority", "Unknown")
        k = c.get("category", "Unknown")
        by_status[s]   = by_status.get(s, 0) + 1
        by_priority[p] = by_priority.get(p, 0) + 1
        by_category[k] = by_category.get(k, 0) + 1

    return jsonify({
        "success": True,
        "data": {
            "total":       total,
            "by_status":   by_status,
            "by_priority": by_priority,
            "by_category": by_category,
            "open":        total - by_status.get("Resolved", 0),
            "resolved":    by_status.get("Resolved", 0),
            "urgent":      by_priority.get("Urgent", 0),
        },
    })


# ── Serve frontend ────────────────────────────────────────────────────────────
@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.get("/<path:filename>")
def static_files(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ── 404 ───────────────────────────────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Route not found."}), 404


# ── Run ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(debug=True, port=5000)
